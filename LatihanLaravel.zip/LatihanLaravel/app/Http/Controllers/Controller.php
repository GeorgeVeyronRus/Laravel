<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Mahasiswa as MahasiswaModel;
use App\Models\Jurusan as JurusanModel;
use App\Models\KampusBinus as KampusBinusModel;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    public function show(){
        return view('layouts.master');
    }

    public function mahasiswa(){
        $jurusan = JurusanModel::all();
        $dtmahasiswa = MahasiswaModel::all();


        return view('layouts.mahasiswa',['jur'=>$jurusan, 'mhs'=>$dtmahasiswa]);
    }
}
