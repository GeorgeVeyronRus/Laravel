

<?php $__env->startSection('title', 'Mahasiswa'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6" style ="border: 1px solid black">
            <h1>Data Mahasiswa</h1>
            <table class="table">
                <thead>
                        <tr>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Jurusan</th>
                            <th>Kampus</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtmhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($dtmhs->nim); ?></td>
                            <td><?php echo e($dtmhs->nama); ?></td>
                            <td><?php echo e($dtmhs->jurusan->nama_jurusan); ?></td>
                            <td><?php echo e($dtmhs->kampusBinus->nama_kampus); ?></td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td>data kosong</td>
                            <?php endif; ?>
                    </tbody>
                    <
            </table>
        </div>
        <div class="col-md-6"style= "border: 1px solid black">
            <h1>Data Jurusan</h1>
            <table class="table">
                <thead>
                    <tr>
                        <th>Nama Jurusan</th>
                        <th>Deskripsi</th>
                        <th>List Mahasiswa</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $jur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($jr->nama_jurusan); ?></td>
                        <td><?php echo e($jr->deskripsi); ?></td>
                        
                        <td>
                        <?php $__currentLoopData = $jr->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurmhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($jurmhs->nama); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td>data kosong</td>
                    <?php endif; ?>
                </tbody>
                </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\George\LatihanLaravel\resources\views/layouts/mahasiswa.blade.php ENDPATH**/ ?>