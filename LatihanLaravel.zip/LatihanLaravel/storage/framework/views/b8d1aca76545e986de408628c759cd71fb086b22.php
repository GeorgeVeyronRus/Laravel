

<?php $__env->startSection('title', 'Mahasiswa'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6" style ="border: 1px solid black">
            <h1>Ini Column 1</h1>
        </div>
        <div class="col-md-6"style= "border: 1px solid black">
            <h1>Ini Column 2</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\George\LatihanLaravel\resources\views/layouts/about.blade.php ENDPATH**/ ?>